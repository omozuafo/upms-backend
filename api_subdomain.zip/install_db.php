<?php
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

define('LARAVEL_START', microtime(true));
require __DIR__.'/../../backend/vendor/autoload.php';
$app = require_once __DIR__.'/../../backend/bootstrap/app.php';

header('Content-Type: application/json');

try {
    $pdo = DB::connection()->getPdo();
    $driver = DB::connection()->getDriverName();
    $database = DB::connection()->getDatabaseName();

    Artisan::call('migrate', ['--force' => true]);
    $migrateOutput = Artisan::output();

    Artisan::call('admin:ensure');
    $ensureOutput = Artisan::output();

    $hasUsers = Schema::hasTable('users');
    $superAdmin = $hasUsers ? DB::table('users')->where('email', 'figuriad@gmail.com')->first() : null;

    echo json_encode([
        'status' => 'success',
        'driver' => $driver,
        'database' => $database,
        'has_users_table' => $hasUsers,
        'super_admin_exists' => (bool)$superAdmin,
        'migrate_output' => $migrateOutput,
        'ensure_output' => $ensureOutput,
    ], JSON_PRETTY_PRINT);
} catch (\Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'error_class' => get_class($e),
        'message' => $e->getMessage(),
        'trace' => $e->getTraceAsString(),
    ], JSON_PRETTY_PRINT);
}
