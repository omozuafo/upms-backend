<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\UnitController;

echo "Checking unit access for City Gate...\n";

// Find City Gate property
$property = Property::where('name', 'City Gate')->first();
if (!$property) die("Property 'City Gate' not found.");

echo "Testing with Property: {$property->name} (ID: {$property->id})\n";

$controller = new UnitController();
$request = Request::create('/api/units', 'GET', ['property_id' => $property->id]);

try {
    $response = $controller->index($request);
    $data = $response->getData();
    $units = is_array($data) ? $data : (isset($data->data) ? $data->data : $data);
    $count = is_array($units) ? count($units) : $units->count();
    
    echo "Fetched {$count} units for property {$property->id}.\n";
    
    if ($count > 0) {
        foreach ($units as $u) {
            echo "- Unit: {$u->unit_number} (Status: {$u->status})\n";
        }
    } else {
        echo "Property has no units.\n";
    }

} catch (\Exception $e) {
    echo "Error fetching units: " . $e->getMessage() . "\n";
}
