<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Property;
use App\Models\Unit;

$property = Property::where('name', 'City Gate')->first();

if (!$property) {
    die("Property 'City Gate' not found.\n");
}

echo "Renaming units for '{$property->name}'...\n";

$units = Unit::where('property_id', $property->id)->get();

foreach ($units as $unit) {
    if (str_contains($unit->unit_number, 'Block A - ')) {
        $newNumber = str_replace('Block A - ', '', $unit->unit_number);
        $unit->update(['unit_number' => $newNumber]);
        echo "Renamed '{$unit->unit_number}' to '{$newNumber}'\n";
    }
}

echo "Done.\n";
