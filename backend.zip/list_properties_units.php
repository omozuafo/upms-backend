<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Property;
use App\Models\Unit;

$properties = Property::all();

echo "Listing Properties and their Unit counts:\n";
foreach ($properties as $p) {
    $realUnitCount = Unit::where('property_id', $p->id)->count();
    echo "Property: {$p->name} (ID: {$p->id}) - DB Status Units Count: {$p->units_count} - Actual Units Found: {$realUnitCount}\n";
}
