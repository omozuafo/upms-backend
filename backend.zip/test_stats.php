<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$user = \App\Models\User::where('role', 'accounting_staff')->first();
if (!$user) {
    echo "No accounting staff found\n";
    exit;
}

\Illuminate\Support\Facades\Auth::login($user);

$controller = new \App\Http\Controllers\DashboardController();
$response = $controller->stats(new \Illuminate\Http\Request());
$data = $response->getData();

file_put_contents('dashboard_stats.json', json_encode($data, JSON_PRETTY_PRINT));
echo "Done\n";
