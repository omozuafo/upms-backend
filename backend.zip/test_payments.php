<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$payments = \App\Models\Payment::with(['tenant', 'property'])->orderBy('payment_date', 'desc')->take(5)->get();
file_put_contents('recent_payments_dump.json', json_encode($payments, JSON_PRETTY_PRINT));
echo "Done\n";
