<?php

require __DIR__ . '/vendor/autoload.php';

$client = new \GuzzleHttp\Client(['base_uri' => 'http://127.0.0.1:8000/api/']);

function testRegistration($role, $expectedStatus) {
    global $client;
    echo "Testing registration for role: $role\n";
    try {
        $response = $client->post('auth/register', [
            'json' => [
                'name' => 'Test User ' . $role,
                'email' => 'test_' . $role . '_' . time() . '@example.com',
                'password' => 'password',
                'password_confirmation' => 'password',
                'phone' => '1234567890',
                'role' => $role
            ]
        ]);
        
        $status = $response->getStatusCode();
        echo "Status: $status. Expected: $expectedStatus.\n";
        
        if ($status == $expectedStatus) {
            echo "PASS\n";
        } else {
            echo "FAIL\n";
        }
        
    } catch (\GuzzleHttp\Exception\ClientException $e) {
        $status = $e->getResponse()->getStatusCode();
        echo "Status: $status. Expected: $expectedStatus.\n";
        echo "Response: " . $e->getResponse()->getBody()->getContents() . "\n";
        
        if ($status == $expectedStatus) {
            echo "PASS\n";
        } else {
            echo "FAIL\n";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage() . "\n";
        echo "FAIL\n";
    }
    echo "-----------------------------------\n";
}

// Ensure we have at least one admin and super admin (should be seeded already)
// If not, the first run might succeed (which is fine, subsequent runs should fail)
// But based on previous context, they exist.

testRegistration('super_admin', 403);
testRegistration('admin', 403);
testRegistration('tenant', 201);
