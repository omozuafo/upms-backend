<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\Property;
use App\Models\Unit;

$property = Property::where('name', 'City Gate')->first();

if (!$property) {
    die("Property 'City Gate' not found.\n");
}

$currentUnits = Unit::where('property_id', $property->id)->count();
$targetUnits = max($property->units_count, 3); // Ensure at least 3 units

echo "Seeding units for '{$property->name}' (Target: {$targetUnits}, Current: {$currentUnits})...\n";

for ($i = $currentUnits + 1; $i <= $targetUnits; $i++) {
    Unit::create([
        'property_id' => $property->id,
        'unit_number' => "Block A - Unit {$i}",
        'floor' => 1,
        'type' => '2BHK',
        'status' => 'Vacant',
        'rent_amount' => 1500,
        'description' => 'Newly created unit for testing',
    ]);
    echo "Created Unit {$i}\n";
}

echo "Done.\n";
