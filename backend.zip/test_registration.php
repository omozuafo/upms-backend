<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

echo "Testing Registration with Phone Number...\n";

// Mock Request Data
$requestData = [
    'name' => 'Test Phone User',
    'email' => 'phone_test_' . time() . '@example.com',
    'phone' => '1234567890',
    'password' => 'password123',
    'password_confirmation' => 'password123',
    'role' => 'tenant'
];

$request = Request::create('/api/auth/register', 'POST', $requestData);

$controller = new AuthController();

try {
    $response = $controller->register($request);
    $data = $response->getData();
    
    if ($response->getStatusCode() === 201) {
        echo "Registration Successful!\n";
        echo "User ID: " . $data->user->id . "\n";
        echo "User Name: " . $data->user->name . "\n";
        echo "User Email: " . $data->user->email . "\n";
        echo "User Phone: " . $data->user->phone . "\n";
        
        // Verify in DB just to be sure
        $user = User::find($data->user->id);
        if ($user && $user->phone === '1234567890') {
            echo "DB Verification: PASSED (Phone matches)\n";
        } else {
            echo "DB Verification: FAILED (Phone mismatch or user not found)\n";
        }
    } else {
        echo "Registration Failed with Status " . $response->getStatusCode() . "\n";
        print_r($data);
    }

} catch (\Exception $e) {
    echo "Error During Registration: " . $e->getMessage() . "\n";
    // Check validation errors if possible
    if (method_exists($e, 'getResponse')) {
         print_r($e->getResponse()->getContent());
    }
}
