<?php

require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

$users = [
    [
        'name' => 'System Super Admin',
        'email' => 'superadmin@upms.com',
        'password' => Hash::make('asdfghj69.'),
        'role' => 'super_admin',
        'username' => 'superadmin'
    ],
    [
        'name' => 'System Admin',
        'email' => 'admin@example.com',
        'password' => Hash::make('password123'),
        'role' => 'admin',
        'username' => 'sysadmin'
    ],
    [
        'name' => 'Accounting Staff',
        'email' => 'account@example.com',
        'password' => Hash::make('password123'),
        'role' => 'accounting_staff',
        'username' => 'accounting'
    ],
    [
        'name' => 'Maintenance Staff',
        'email' => 'maintenance@example.com',
        'password' => Hash::make('password123'),
        'role' => 'maintenance_staff',
        'username' => 'maintenance'
    ]
];

foreach ($users as $userData) {
    $existing = User::where('email', $userData['email'])->first();
    if (!$existing) {
        User::create($userData);
        echo "Created user: {$userData['email']}\n";
    } else {
        // Update password just in case they were trying to login with an old password or something
        $existing->password = $userData['password'];
        $existing->save();
        echo "Updated password for existing user: {$userData['email']}\n";
    }
}
echo "All done.\n";
