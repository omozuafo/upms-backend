<?php
require 'vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use App\Models\Issue;
use App\Models\Unit;
use App\Models\Property;

// 1. Find a property with occupied units
$property = Property::first();
$units = Unit::where('property_id', $property->id)->whereNotNull('tenant_id')->get();
if ($units->count() > 0) {
    echo "Found property: {$property->name} with {$units->count()} tenants.\n";
    
    // Create an issue without a unit
    $issue = Issue::create([
        'title' => 'Test Roof Fix',
        'description' => 'Leaking roof',
        'property_id' => $property->id,
        'unit_id' => null,
        'priority' => 'High',
        'status' => 'Open',
        'reported_by' => User::where('role', 'maintenance_staff')->first()->id ?? 1,
        'reported_at' => now(),
    ]);

    echo "Created Issue #{$issue->id}\n";

    // Create split array
    $split = [];
    $totalBudget = 0;
    foreach ($units as $index => $u) {
        $amount = ($index + 1) * 1000; // 1000 for first, 2000 for second etc.
        $split[] = [
            'tenant_id' => $u->tenant_id,
            'amount' => $amount
        ];
        $totalBudget += $amount;
        echo "Assigned Tenant #{$u->tenant_id} charge of $amount\n";
    }

    // Submit Budget
    $issue->update([
        'budget_cost' => $totalBudget,
        'maintenance_report' => 'Replacing roof tiles',
        'tenant_budget_split' => $split,
        'account_review_status' => 'Pending'
    ]);
    
    echo "Saved Budget Split. Total: $totalBudget\n";
    
    // Simulate Account User Login
    $admin = User::where('role', 'admin')->first() ?? User::where('role', 'super_admin')->first();
    Auth::login($admin);
    
    // Test API call to accountAction
    $request = Request::create("/api/issues/{$issue->id}/account-action", 'POST', ['action' => 'Accept']);
    $response = app()->handle($request);
    
    echo "Action executed. Status: " . $response->getStatusCode() . "\n";
    
    // Verify deductions
    foreach ($split as $s) {
        $t = User::find($s['tenant_id']);
        echo "Tenant ID {$t->id} current balance: {$t->wallet_balance}\n";
    }
} else {
    echo "No suitable property found.";
}
