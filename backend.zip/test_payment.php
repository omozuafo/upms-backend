<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$payment = \App\Models\Payment::with(['tenant', 'property'])->first();
file_put_contents('payment_dump.json', json_encode($payment, JSON_PRETTY_PRINT));
echo "Done\n";
