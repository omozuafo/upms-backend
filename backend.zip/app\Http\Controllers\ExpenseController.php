<?php

namespace App\Http\Controllers;

use App\Models\Expense;
use App\Models\Notification;
use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ExpenseController extends Controller
{
    public function index(Request $request)
    {
        $query = Expense::with(['property', 'unit.tenant:id,name,email', 'creator']);

        if ($request->has('property_id') && $request->property_id !== 'All') {
            $query->where('property_id', $request->property_id);
        }

        if ($request->has('category') && $request->category !== 'All') {
            $query->where('category', $request->category);
        }

        if ($request->has('status') && $request->status !== 'All') {
            $query->where('status', $request->status);
        }

        return response()->json($query->orderBy('created_at', 'desc')->get());
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'property_id' => 'nullable|exists:properties,id',
            'unit_id' => 'nullable|exists:units,id',
            'amount' => 'required|numeric|min:0',
            'purpose' => 'nullable|string|max:255',
            'receipt_number' => 'nullable|string|max:255',
            'account_name' => 'nullable|string|max:255',
            'account_number' => 'nullable|string|max:255',
            'payment_timestamp' => 'nullable|date',
            'date' => 'required|date',
            'category' => 'nullable|string',
            'description' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $data = $request->all();
        if (array_key_exists('property_id', $data) && ($data['property_id'] === '' || $data['property_id'] === 'none' || $data['property_id'] === 'null' || $data['property_id'] === null)) {
            $data['property_id'] = null;
        }
        if (array_key_exists('unit_id', $data) && ($data['unit_id'] === '' || $data['unit_id'] === 'none' || $data['unit_id'] === 'null' || $data['unit_id'] === null)) {
            $data['unit_id'] = null;
        }
        $data['created_by'] = Auth::id() ?? auth('api')->id();
        $data['status'] = $data['status'] ?? 'Pending';
        if (empty($data['category'])) {
            $data['category'] = $data['purpose'] ?? 'General Expense';
        }

        $expense = Expense::create($data);
        $expense->load(['property', 'unit.tenant:id,name,email', 'creator']);

        // Notify Admins about new expense submission
        $adminIds = User::whereIn('role', ['admin', 'super_admin'])->pluck('id')->toArray();
        NotificationService::send($adminIds, [
            'type' => 'expense',
            'title' => 'New Expense Submission',
            'message' => 'New expense claim (' . ($expense->receipt_number ? '#' . $expense->receipt_number : '₦' . number_format($expense->amount)) . ') submitted for review.',
            'reference_id' => $expense->id,
        ]);

        return response()->json($expense, 201);
    }

    public function show($id)
    {
        $expense = Expense::with(['property', 'creator'])->find($id);
        if (!$expense) {
            return response()->json(['message' => 'Expense not found'], 404);
        }
        return response()->json($expense);
    }

    public function update(Request $request, $id)
    {
        $expense = Expense::find($id);
        if (!$expense) {
            return response()->json(['message' => 'Expense not found'], 404);
        }

        $data = $request->all();
        if (array_key_exists('property_id', $data) && ($data['property_id'] === '' || $data['property_id'] === 'none' || $data['property_id'] === 'null' || $data['property_id'] === null)) {
            $data['property_id'] = null;
        }
        if (array_key_exists('unit_id', $data) && ($data['unit_id'] === '' || $data['unit_id'] === 'none' || $data['unit_id'] === 'null' || $data['unit_id'] === null)) {
            $data['unit_id'] = null;
        }

        $expense->update($data);
        $expense->load(['property', 'unit.tenant:id,name,email', 'creator']);
        return response()->json($expense);
    }

    public function destroy($id)
    {
        $expense = Expense::find($id);
        if (!$expense) {
            return response()->json(['message' => 'Expense not found'], 404);
        }

        $expense->delete();
        return response()->json(['message' => 'Expense deleted']);
    }

    public function approve($id)
    {
        $expense = Expense::find($id);
        if (!$expense) {
            return response()->json(['message' => 'Expense not found'], 404);
        }

        $expense->update([
            'status' => 'Approved',
            'rejection_reason' => null
        ]);

        $targetUserIds = $expense->created_by ? [$expense->created_by] : User::where('role', 'accounting_staff')->pluck('id')->toArray();
        NotificationService::send($targetUserIds, [
            'type' => 'expense',
            'title' => 'Expense Approved',
            'message' => 'Your expense claim (' . ($expense->receipt_number ? '#' . $expense->receipt_number : '₦' . number_format($expense->amount)) . ') for ' . ($expense->purpose ?? $expense->category) . ' has been APPROVED by admin.',
            'reference_id' => $expense->id,
        ]);

        return response()->json([
            'message' => 'Expense approved successfully',
            'expense' => $expense->fresh(['property', 'creator'])
        ]);
    }

    public function reject(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'rejection_reason' => 'required|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        $expense = Expense::find($id);
        if (!$expense) {
            return response()->json(['message' => 'Expense not found'], 404);
        }

        $expense->update([
            'status' => 'Rejected',
            'rejection_reason' => $request->rejection_reason,
        ]);

        $targetUserIds = $expense->created_by ? [$expense->created_by] : User::where('role', 'accounting_staff')->pluck('id')->toArray();
        NotificationService::send($targetUserIds, [
            'type' => 'expense',
            'title' => 'Expense Rejected',
            'message' => 'Your expense claim (' . ($expense->receipt_number ? '#' . $expense->receipt_number : '₦' . number_format($expense->amount)) . ') was REJECTED. Reason: ' . $request->rejection_reason,
            'reference_id' => $expense->id,
        ]);

        return response()->json([
            'message' => 'Expense rejected',
            'expense' => $expense->fresh(['property', 'creator'])
        ]);
    }
}
