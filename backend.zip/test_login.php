<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Http\Request;
use App\Http\Controllers\AuthController;

echo "Testing Login for Admin...\n";

$requestData = [
    'email' => 'admin@example.com',
    'password' => 'password'
];

$request = Request::create('/api/auth/login', 'POST', $requestData);
$controller = new AuthController();

try {
    $response = $controller->login($request);
    echo "Status: " . $response->getStatusCode() . "\n";
    print_r($response->getData());
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
